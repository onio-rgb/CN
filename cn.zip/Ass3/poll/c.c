#include<stdlib.h>
int main()
{
    system("gcc p1.c -o p1");
    system("gcc p2.c -o p2");
    system("gcc p3.c -o p3");
    system("gcc p4.c -o p4");
    system("gcc p5.c -o p5");
    system("gcc p6.c -o p6");
}